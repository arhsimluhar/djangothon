.. :changelog:

History
-------

0.1.0 (2018-11-18)
++++++++++++++++++

* First release on PyPI.
